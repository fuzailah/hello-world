<?php

@session_start(  );
header( 'Content-Type: text/html; charset=UTF-8' );

//if ($_SERVER['HTTP_HOST'] != '127.0.0.1') {
//    error_reporting(30719 & ~8192 & ~8 & ~2);
//    @set_magic_quotes_runtime(false);
//    ini_set('short_tags', false);
//}

ini_set( 'memory_limit', '64M' );
ini_set( 'track_errors', true );
ini_set( 'magic_quotes_sybase', false );

include( 'database.php' );
include( dirname( dirname( __FILE__ ) ) . '/language/en.php' );
include_once( 'functions.php' );

$q = 'SELECT password  FROM user_account WHERE user_account_id =  \'' . $_SESSION['user_account_id'] . '\' ';
if (!( $r = mysql_query( $q ))) {
    exit(mysql_error());
}

$row = mysql_fetch_array( $r );
if ($row['password'] != $_SESSION['password']) {
    $_SESSION['user_account_id'] = 0;
    session_destroy();
    header('Location: login.php');
    exit();
}

//if (!isset( $_SESSION['white_label']['background_path'] )) {
    $q = 'SELECT * FROM white_label ';
    $r = mysql_query($q);
    $row = mysql_fetch_assoc($r);

    $_SESSION['white_label']['logo_path'] = $row['logo_path'];
    $_SESSION['white_label']['title'] = $row['title'];
    $_SESSION['white_label']['hide_footer'] = $row['hide_footer'];
    $_SESSION['white_label']['favicon_path'] = $row['favicon_path'];
    $_SESSION['white_label']['email_required'] = $row['email_required'];
    $_SESSION['white_label']['tag_line'] = $row['tag_line'];
    $_SESSION['white_label']['footer_licensed'] = $row['footer_licensed'];
    $_SESSION['white_label']['footer_powered'] = $row['footer_powered'];
    $_SESSION['white_label']['meta_title'] = $row['meta_title'];
    $_SESSION['white_label']['meta_keywords'] = $row['meta_keywords'];
    $_SESSION['white_label']['meta_description'] = $row['meta_description'];
    $_SESSION['white_label']['tracking_script'] = $row['tracking_script'];
    $_SESSION['white_label']['header_message'] = $row['header_message'];

    if ($row['background_path']) {
        $_SESSION['white_label']['background_path'] = ($row['background_path'] ? 'temp/' . $row['background_path'] : 'img/placeholders/headers/login_header.jpg');
    }

    if ($row['subscriber_label']) {
        $_SESSION['white_label']['subscriber_label'] = (true ? $row['subscriber_label'] : 'Subscriber');
    }
//}


$lic_res['companyname'] = 'Radio Objetiva Sat';
$lis_res['regdate'] = '2016-11-25';
$lic_res['nextduedate'] = 'Never';

$active_addons_list = array();

// modules
array_push( $active_addons_list, 'Domain Masking');
array_push( $active_addons_list, 'Multi MTA / SMTP');
array_push( $active_addons_list, 'PowerMTA Integration and Bounce Processor');
array_push( $active_addons_list, 'Spin Tags');
array_push( $active_addons_list, 'Auto Backup Module');
array_push( $active_addons_list, 'Multi Threading');
array_push( $active_addons_list, 'White Labeling' );
array_push( $active_addons_list, 'Email Verifier' );
array_push( $active_addons_list, 'User Management' );
array_push( $active_addons_list, 'Geo Location Tool' );
array_push( $active_addons_list, 'Feedback Loops Processor' );
array_push( $active_addons_list, 'Dynamic Content Tags' );
array_push( $active_addons_list, 'Auto Responders' );
array_push( $active_addons_list, 'Adknowledge Integration' );
array_push( $active_addons_list, 'Responsive Newsletter Templates' );
array_push( $active_addons_list, 'IP/Domain Reputation Monitor' );
array_push( $active_addons_list, 'Split Tests' );
array_push( $active_addons_list, 'Triggers' );
array_push( $active_addons_list, 'Website Forms' );
array_push( $active_addons_list, 'Advance Export' );
array_push( $active_addons_list, 'White' );
array_push( $active_addons_list, 'White' );
array_push( $active_addons_list, 'White' );
$_SESSION['active_addons_list'] = $active_addons_list;


$template = array( 'name' => 'MUMARA', 'version' => '1.0', 'author' => '', 'robots' => 'noindex, nofollow', 'title' => 'MUMARA', 'description' => 'MUMARA', 'header_navbar' => 'navbar-default', 'header' => '', 'sidebar' => 'sidebar-partial sidebar-visible-lg sidebar-no-animations', 'footer' => '', 'main_style' => '', 'theme' => '', 'header_content' => '', 'active_page' => basename( $_SERVER['PHP_SELF'] ) );

$PRODUCTNAME = 'MUMARA';

$primary_nav = array (
    array (
        'name' => 'Dashboard',
        'icon' => 'gi gi-stopwatch ',
        'url' => 'index.php',
    ),
    array (
        'name' => 'My Lists',
        'icon' => 'gi gi-notes_2 ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a List',
                    'url' => 'new_list.php'
                ),
                array (
                    'name' => 'View all Lists',
                    'url' => 'view_lists.php'
                ),
                array (
                    'name' => 'Create Custom Fields',
                    'url' => 'new_custom_fields.php'
                ),
                array (
                    'name' => 'View Custom Fields',
                    'url' => 'view_custom_fields.php'
                ),
                array (
                    'name' => 'Segmentation',
                    'url' => 'view_list_segments.php'
                ),
                array (
                    'name' => 'View Segments',
                    'url' => 'view_scheduled_segments.php'
                ),
                array (
                    'name' => 'Emails Suppression',
                    'url' => 'import_suppressed_contacts.php'
                ),
                array (
                    'name' => 'Domains Suppression',
                    'url' => 'suppress_domain.php'
                ),
                array (
                    'name' => 'IP(s) Suppression',
                    'url' => 'suppress_ip.php'
                )
            )
    ),
    array (
        'name' => 'Subscribers',
        'icon' => 'gi gi-envelope ',
        'sub' =>
            array (
                array (
                    'name' => 'Add a Subscriber',
                    'url' => 'new_contacts.php'
                ),
                array (
                    'name' => 'View all Subscribers',
                    'url' => 'view_contacts.php'
                ),
                array (
                    'name' => 'Delete Subscribers',
                    'url' => 'delete_contacts.php'
                ),
                array (
                    'name' => 'Import Subscribers from a File',
                    'url' => 'import_contacts.php'
                ),
                array (
                    'name' => 'Export Subscribers to a File',
                    'url' => 'export_contacts.php'
                ),
                array (
                    'name' => 'Bulk Subscribers Update',
                    'url' => 'bulk_subscriber_update.php'
                )
            )
    ),
    array (
        'name' => 'My Campaigns',
        'icon' => 'fa fa-exchange ',
        'sub' =>
            array (
                array (
                    'name' => 'Create an Email Campaign',
                    'url' => 'new_campaign.php'
                ),
                array (
                    'name' => 'View all Email Campaigns',
                    'url' => 'view_campaign.php'
                ),
                array (
                    'name' => 'Schedule an Email Campaign',
                    'url' => 'schedule_campaign.php'
                ),
                array (
                    'name' => 'Schedule Multiple Campaigns',
                    'url' => 'multiple_schedule_campaign.php'
                ),
                array (
                    'name' => 'View Scheduled Campaigns',
                    'url' => 'view_schedule_campaign.php'
                ),
                array (
                    'name' => 'Schedule Evergreen Campaign',
                    'url' => 'schedule_evergreen_campaign.php'
                ),
                array (
                    'name' => 'View Evergreen Campaigns',
                    'url' => 'view_schedule_evergreen_campaign.php'
                ),
                array (
                    'name' => 'Create a Split Test',
                    'url' => 'new_email_split_campaign.php'
                ),
                array (
                    'name' => 'View Split Tests',
                    'url' => 'view_email_split_campaign.php'
                )
            )
    ),
    array (
        'name' => 'Autoresponders',
        'icon' => 'fa fa-bullhorn ',
        'sub' =>
            array (
                array (
                    'name' => 'Create an Autoresponder',
                    'url' => 'new_autoresponders.php'
                ),
                array (
                    'name' => 'View Autoresponders',
                    'url' => 'view_autoresponders.php'
                ),
                array (
                    'name' => 'Create Autoresponders Group',
                    'url' => 'new_autoresponders_group.php'
                ),
                array (
                    'name' => 'View Autoresponders Groups',
                    'url' => 'view_autoresponders_group.php'
                ),
                array (
                    'name' => 'Create Sending Criteria',
                    'url' => 'new_autoresponders_criteria.php'
                ),
                array (
                    'name' => 'View Sending Criteria',
                    'url' => 'view_autoresponders_criteria.php'
                )
            )
    ),
    array (
        'name' => 'Triggers (Actions)',
        'icon' => 'hi hi-time ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a Trigger',
                    'url' => 'new_trigger.php'
                ),
                array (
                    'name' => 'View Triggers (Actions)',
                    'url' => 'view_trigger.php'
                ),
                array (
                    'name' => 'Trigger Notification Email',
                    'url' => 'new_notification.php'
                )
            )
    ),
    array (
        'name' => 'Dynamic Content',
        'icon' => 'fa fa-list-alt fa-fw ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a Dynamic Content Tag',
                    'url' => 'new_dynamic_content_tag.php'
                ),
                array (
                    'name' => 'View all Dynamic Content Tags',
                    'url' => 'view_dynamic_content_tag.php'
                )
            )
    ),
    array (
        'name' => 'Spintags',
        'icon' => 'fa fa-bullseye ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a Spintag',
                    'url' => 'new_spin_tag.php'
                ),
                array (
                    'name' => 'View all Spintags',
                    'url' => 'view_spin_tag.php'
                )
            )
    ),
    array (
        'name' => 'Image/File Manager',
        'icon' => 'fa fa-picture-o fa-fw ',
        'sub' =>
            array (
                array (
                    'name' => 'Add a File or Image',
                    'url' => 'image_upload.php'
                ),
                array (
                    'name' => 'View Gallery',
                    'url' => 'image_view.php'
                )
            )
    ),
    array (
        'name' => 'Website Forms',
        'icon' => 'fa fa-list-alt fa-fw ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a Web Form',
                    'url' => 'new_web_forms.php'
                ),
                array (
                    'name' => 'View Web Forms',
                    'url' => 'view_web_forms.php'
                )
            )
    ),
    array (
        'name' => 'Statistics',
        'icon' => 'gi gi-charts ',
        'sub' =>
            array (
                array (
                    'name' => 'Email Campaign Stats',
                    'url' => 'view_stats_schedule_campaign.php'
                ),
                array (
                    'name' => 'Adknowledge Campaign Stats',
                    'url' => 'view_stats_adknowledge_campaign.php'
                ),
                array (
                    'name' => 'Autoresponder Stats',
                    'url' => 'view_stats_autoresponder.php'
                ),
                array (
                    'name' => 'Auto Responder Group Stats',
                    'url' => 'view_stats_autoresponder_group.php'
                ),
                array (
                    'name' => 'Trigger Stats',
                    'url' => 'view_stats_triggers.php'
                ),
                array (
                    'name' => 'Split Test Stats',
                    'url' => 'view_stats_split_campaign.php'
                ),
                array (
                    'name' => 'Global Stats',
                    'url' => 'view_stats_sending.php'
                ),
                array (
                    'name' => 'Notification Email',
                    'url' => 'schedule_campaign_notification.php'
                )
            )
    ),
    array (
        'name' => 'Bounce',
        'icon' => 'gi gi-message_in ',
        'sub' =>
            array (
                array (
                    'name' => 'Configure a Bounce Email',
                    'url' => 'new_bounce.php'
                ),
                array (
                    'name' => 'View Bounce Emails',
                    'url' => 'view_bounce.php'
                ),
                array (
                    'name' => 'Bounce Reasons',
                    'url' => 'new_bounce_reasons.php'
                ),
                array (
                    'name' => 'View Bounce Reasons',
                    'url' => 'view_bounce_reasons.php'
                )
            )
    ),
    array (
        'name' => 'Feedback Loops(FBL)',
        'icon' => 'fa fa-check-circle-o ',
        'sub' =>
            array (
                array (
                    'name' => 'Configure a Feedback Loop',
                    'url' => 'new_feedback_loop.php'
                ),
                array (
                    'name' => 'View Feedback Loops',
                    'url' => 'view_feedback_loop.php'
                ),
                array (
                    'name' => 'Processed Feedback Loops',
                    'url' => 'view_feedback_loop_list.php'
                )
            )
    ),
    array (
        'name' => 'SMTP Accounts',
        'icon' => 'fa fa-lock ',
        'sub' =>
            array (
                array (
                    'name' => 'Setup an SMTP Account',
                    'url' => 'new_smtp.php'
                ),
                array (
                    'name' => 'View all SMTP Accounts',
                    'url' => 'view_smtp.php'
                )
            )
    ),
    array (
        'name' => 'Domain Masking',
        'icon' => 'fa fa-sitemap ',
        'sub' =>
            array (
                array (
                    'name' => 'Setup Domain Masking',
                    'url' => 'new_mask_domain.php'
                ),
                array (
                    'name' => 'View all Masked Domains',
                    'url' => 'view_mask_domain.php'
                )
            )
    ),
    array (
        'name' => 'Email Templates',
        'icon' => 'gi gi-brush ',
        'sub' =>
            array (
                array (
                    'name' => 'Create an Email Template',
                    'url' => 'new_email_template.php'
                ),
                array (
                    'name' => 'View all Email Templates',
                    'url' => 'view_email_template.php'
                )
            )
    ),
    array (
        'name' => 'Integrations',
        'icon' => 'fa fa-cogs ',
        'sub' =>
            array (
                array (
                    'name' => 'Email Application API',
                    'url' => 'api_integration.php'
                ),
                array (
                    'name' => 'Adknowledge Integration',
                    'url' => 'adknowledge_setting.php'
                ),
                array (
                    'name' => 'Mandrill Integration',
                    'url' => 'mandrill_setting.php'
                )
            )
    ),
    array (
        'name' => 'Sub User Accounts',
        'icon' => 'fa fa-user ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a Sub User Role',
                    'url' => 'new_sub_user_role.php'
                ),
                array (
                    'name' => 'View Sub User Roles',
                    'url' => 'view_sub_user_role.php'
                ),
                array (
                    'name' => 'Create a Sub User',
                    'url' => 'new_sub_user_account.php'
                ),
                array (
                    'name' => 'View Sub Users',
                    'url' => 'view_sub_user_account.php'
                )
            )
    ),
    array (
        'name' => 'User Management',
        'icon' => 'fa fa-users ',
        'sub' =>
            array (
                array (
                    'name' => 'Create a User Role',
                    'url' => 'new_user_role.php'
                ),
                array (
                    'name' => 'View User Roles',
                    'url' => 'view_user_role.php'
                ),
                array (
                    'name' => 'Create a User',
                    'url' => 'new_user_account.php'
                ),
                array (
                    'name' => 'View Users',
                    'url' => 'view_user_account.php'
                ),
                array (
                    'name' => 'Add Email Credits',
                    'url' => 'new_credit_addons.php'
                )
            )
    ),
    array (
        'name' => 'Settings',
        'icon' => 'gi gi-settings ',
        'sub' =>
            array (
                array (
                    'name' => 'License Key',
                    'url' => 'license_update.php'
                ),
                array (
                    'name' => 'Application Settings',
                    'url' => 'application_settings.php'
                ),
                array (
                    'name' => 'Activity Log',
                    'url' => 'activity_log.php'
                ),
                array (
                    'name' => 'Custom Headers',
                    'url' => 'custom_header.php'
                ),
                array (
                    'name' => 'Multi Threading',
                    'url' => 'multi_threading.php'
                ),
                array (
                    'name' => 'Email Notification Templates',
                    'url' => 'email_templates_list.php'
                ),
                array (
                    'name' => 'Notifications SMTP',
                    'url' => 'notification_smtp.php'
                ),
                array (
                    'name' => 'Cron Settings',
                    'url' => 'cron_settings.php'
                ),
                array (
                    'name' => 'White Labeling',
                    'url' => 'white_labeling.php'
                )
            )
    ),
    array (
        'name' => 'ESP Setting',
        'icon' => 'fa fa-lock ',
        'sub' =>
            array (
                array (
                    'name' => 'Server Preference',
                    'url' => 'esp_setup.php'
                ),
                array (
                    'name' => 'Create Sending Server',
                    'url' => 'new_esp_server.php'
                ),
                array (
                    'name' => 'View Sending Server',
                    'url' => 'view_esp_server.php'
                ),
                array (
                    'name' => 'IP Blocks',
                    'url' => 'esp_ip_list.php'
                ),
                array (
                    'name' => 'IP Assignment',
                    'url' => 'assing_ip_list.php'
                ),
                array (
                    'name' => 'Contacts Importing',
                    'url' => 'contacts_importing.php'
                ),
                array (
                    'name' => 'Create Support Agents',
                    'url' => 'new_support_user.php'
                ),
                array (
                    'name' => 'View Support Agents',
                    'url' => 'view_support_user.php'
                )
            )
    ),
    array (
        'name' => 'Tools',
        'icon' => 'fa fa-wrench ',
        'sub' =>
            array (
                array (
                    'name' => 'Cron Status',
                    'url' => 'cron_status.php'
                ),
                array (
                    'name' => 'Check Permissions',
                    'url' => 'check_files_permissions.php'
                ),
                #array (
                #    'name' => 'Upgrade Version',
                #    'url' => 'upgrade.php'
                #),
                array (
                    'name' => 'Auto Backup',
                    'url' => 'database_backup.php'
                )
            )
    )
);
